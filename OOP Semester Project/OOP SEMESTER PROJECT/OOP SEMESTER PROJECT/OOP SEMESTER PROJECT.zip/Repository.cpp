#include "Repository.h"
#include<vector>
#include"Staff.h"
/*
* the default 
*/
Repository::Repository()
{

}

/* 
* the default destructor
*/
Repository::~Repository()
{

}
/*
* add a new object to the vector
*/
void Repository::addStaffMember(Staff* newStaff)
{

	this->data.push_back(newStaff);


}
/*
* get all elements from the repository which is a vector
* 
*/
vector<Staff*>Repository::getAllData()const {
	return this->data;
}
/*
* The update functions with the aid of the setters
* 
*/
void Repository::EditElementByName(string name,int trophies,int medals,int wins)
{
	for (Staff* s : this->data) // to go through directly my vector
	{
		if (s->getName() == name)
			s->setMedals(medals);
			s->setWins(wins);
			s->setTrophies(trophies);
	}

}
/*
* here is removing by ID
*/
void Repository::removeByName(string name) {
	int pos=-1;
	for (int i = 0; i < data.size()&&pos==-1; i++) // to go through directly my vector
	{
		if (data[i]->getName() == name)
		{
			pos = i;
			

		}

	}
	if (pos != -1)
	{
		data.erase(data.begin() + pos);
	}
}
/*
* size for repository
*/
int Repository::sizeRepo()
{
	return data.size();

}