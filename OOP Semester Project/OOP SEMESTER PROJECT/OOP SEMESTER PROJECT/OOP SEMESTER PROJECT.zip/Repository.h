#pragma once
#include <vector>
#include "Staff.h"
#include <string>

class Repository
{
private:
	std::vector<Staff*> data;
public:
	Repository();
	~Repository();
	vector<Staff*> getAllData() const;
	void addStaffMember(Staff* newStaff);
	void removeByName(string name);
	void EditElementByName(string name, int trophies, int goals, int wins);
	int sizeRepo();
};
