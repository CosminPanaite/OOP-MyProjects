#pragma once
class TestClasses
{
public:
	TestClasses() = default;
	~TestClasses() = default;
	void testClasses();
	void testRepo();
	void testCtrl();

};

