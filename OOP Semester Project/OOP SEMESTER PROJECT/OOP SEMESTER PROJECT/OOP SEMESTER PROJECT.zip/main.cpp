#include<iostream>
#include"UI.h";
#include"Repository.h";
#include"Controller.h";
#include"TestClasses.h";
using namespace std;

int main()
{	
	Repository repo;
	Controller ctrl(Repository& repo);
	
	UI ui;
	ui.run();
	//TestClasses t;
	//t.testClasses();
}